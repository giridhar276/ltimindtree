# GUI Applications by using tkinter library

from tkinter import *

root = Tk()

# Label -> to write something
# Entry -> to take some input from the user
# Button -> to create a button

root.title("Simple Calculator")
root.geometry("300x300")

Label(root,text="My First App").grid(column=0,row=0)

e1 = Entry(root)
e1.grid(column=0,row=1)
e2 = Entry(root)
e2.grid(column=1,row=1)

def addNum():
    a = int(e1.get())
    b = int(e2.get())
    result = a+b

    Label(root,text=result).grid(column=1,row=2)

Button(root,text="ADD",command=addNum).grid(column=0,row=2)

root.mainloop()











