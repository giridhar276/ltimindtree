#eg1
# This is commanly used for measuring the duration of operation.

import time
'''
start = time.time()

for i in range(1000000000):
    pass

end = time.time()

duration = end - start
print(duration)
'''

# eg2
# sleep() :- pause the execution for a specified number of seconds.

##print("Starting countdown ....")
##time.sleep(2) # pause for 2 seconds
##print("2 seconds passed ..")
##time.sleep(5)
##print("Another 5 seconds passed..")


# eg3
# time.ctime()
# Converts a time expressed in seconds since the epoch.
'''
print(time.time())
print(time.ctime())
'''

#eg4
##
##print(time.localtime())
##
##print(time.localtime().tm_year)
##print(time.localtime().tm_mon)

# eg5
# Formatted time

print(time.strftime("%Y-%m-%d",time.localtime()))
print(time.strftime("%H:%M:%S",time.localtime()))




























