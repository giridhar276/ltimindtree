# os module

import os

#1 getcwd()
# to get the current working directory

#print(os.getcwd())

#2 chdir()
# to change the current working directory

##print("Before:",os.getcwd())
##os.chdir(r"C:\Users\My PC\OneDrive\Desktop\Batches\LTI_Mindtree\batch2\day3")
##print("After:",os.getcwd())

#3 mkdir()
# creating a directory

##path = r"C:\Users\My PC\OneDrive\Desktop\Batches\LTI_Mindtree\batch2\day5"
##os.mkdir(path)
##print("Folder created successfully")

#4 makedirs()

##path = r"C:\Users\My PC\OneDrive\Desktop\Batches\LTI_Mindtree\batch2\day5\f1\f2\f3"
##os.makedirs(path)
##print("All folders created successfully")

#5 listdir()
# to list all the files and folders

##path = r"C:\Users\My PC\OneDrive\Desktop\Batches\LTI_Mindtree\batch2\day4"
##print(os.listdir(path)) # returns a list of all files and folders


#6 remove() -> to delete a file

##path = r"C:\Users\My PC\OneDrive\Desktop\Batches\LTI_Mindtree\batch2\day5\source.txt"
##os.remove(path)
##print("File deleted successfully")

#7 rmdir() -> to remove or delete a folder or directory

##path = r"C:\Users\My PC\OneDrive\Desktop\Batches\LTI_Mindtree\batch2\day5\sample"
##os.rmdir(path)
##print("Folder deleted successfully")


#8 os.path.exists() -> checking the path existence

##path = r"C:\Users\My PC\OneDrive\Desktop\Batches\LTI_Mindtree\batch2\day5\source.txt"
##print(os.path.exists(path))

# shutil() :- move() and copy()
import shutil

# copy() :- to copy a file from 1 folder to another

src = r"C:\Users\My PC\OneDrive\Desktop\Batches\LTI_Mindtree\batch2\day5\source.txt"
dest = r"C:\Users\My PC\OneDrive\Desktop\Batches\LTI_Mindtree\batch2\day4\source.txt"

shutil.copy(src,dest)
print("File Copied")


# move() 




































































