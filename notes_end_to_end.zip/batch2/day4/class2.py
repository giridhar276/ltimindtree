from class1 import Employee

emp1 = Employee("Sam","Kumar",24,9988,"delhi")
emp2 = Employee("John","kumar",56,5544,"mumbai")

print(emp2.fullName())
print(emp1.hrTeam())
print(emp2.salesTeam())
