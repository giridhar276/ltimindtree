# Classes and Objects

# class attribute and instance attribute
'''
class Employee:
    hours = 40   # class attribute
    # common to all the objects of your class

# Object of this class
emp1 = Employee()
emp2 = Employee()

print(emp1.hours)
print(emp2.hours)

# instance attribute
# specific to each object of your class

emp1.name = "Sam"
emp2.name = "John"

print(emp1.name)
print(emp2.name)
'''

# self parameter
'''
class Employee:
    def f1(self):
        print("hello world")

    def f2(self):
        print("Helloo python")

emp1 = Employee()
Employee.f1(emp1)
emp1.f1()
emp1.f2()
'''

#
'''
class Employee:
    def f1(self):
        self.name = "Sam"  # instance attribute
        age = 25

        print(self.name)
        print(age)

    def f2(self):
        print(self.name)
        print(age)

emp1 = Employee()
emp1.f1()
emp1.f2()
'''

# special method
# __init__()
# constructor in python
'''
class Employee:
    def __init__(self):
        self.name = "sam"

    def f2(self):
        print(self.name)

emp1 = Employee()
##emp1.f1()
emp1.f2()
'''

#
'''
class Employee:
    def __init__(self,first,last,age,phone,address):
        self.first = first
        self.last = last
        self.age = age
        self.phone = phone
        self.address = address

    def fullName(self):
        return f"{self.first} {self.last}"

    def hrTeam(self):
        return f"{self.fullName()} - {self.age}"

    def salesTeam(self):
        return f"{self.fullName()} - {self.phone} - {self.address}"

'''

# inheritance
'''
Inheritance enable us to define a class that takes all the functionality
from the parent class and allows us to add more.

The new class is called the child clas or sub class
and the one from which it inherits
is called the base class or parent class.
'''

# Types of inheritance

#1 Direct inheritance
# A -> B
'''
class A:
    def f1(self):
        print("f1 from class A")

class B(A):
    def f2(self):
        print("f2 from class B")

b = B()
b.f2()
b.f1()
'''

#2 Multilevel inheritance
# A -> B -> C
'''
class A:
    def f1(self):
        print("f1 from class A")

class B(A):
    def f2(self):
        print("f2 from class B")

class C(B):
    def f3(self):
        print("f3 from class C")

c = C()
c.f3()
c.f2()
c.f1()

b = B()
b.f2()
b.f1()
'''

#3 Multiple inheritance
# A -> C <- B

class A:
    def f1(self):
        print("f1 from class A")

class B:
    def f2(self):
        print("f2 from class B")

class C(A,B):
    def f3(self):
        print("f3 from class C")

c = C()
c.f3()
c.f2()
c.f1()




















        































































































        




























































