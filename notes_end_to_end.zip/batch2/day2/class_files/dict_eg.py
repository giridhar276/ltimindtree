# Dictionary Examples

#1
'''
squares = {}
for i in range(1,11):
    squares[i] = i**2
print(squares)
'''

# while loop

# print numbers from 1 to 10
'''
n = 1
while n<=10:
    print(n)
    n = n+1 # n += 1

print("Bye")
'''

#eg
'''
1) Add New Student
{sam:[87,67,54],john:[90,76,54]}
2) Check Result
-> enter name: john
'''

student = {}  # empty dictionary
while True:
    print("1. Add New Student\n2. Check Result\n3. Exit")
    ch = int(input("Enter choice:"))

    if ch == 1:
        name = input("Enter name:")  # key
        # value
        s1 = int(input("Enter marks in Sub1:"))
        s2 = int(input("Enter marks in Sub2:"))
        s3 = int(input("Enter marks in Sub3:"))

        # store data into dictionary
        student[name] = [s1,s2,s3]
        print(student)

    elif ch == 2:
        name = input("Enter your name to check your result:")
        if name in student:
            print("-- Data Found --")
            print(student[name])  # [56,78,90]
            perc = sum(student[name])/3
            print("Percentage: %.2f"%perc)
            print("-"*30)
        else:
            print("-- Data Not Found --")

    elif ch == 3:
        break   # to exit from any loop






            
































