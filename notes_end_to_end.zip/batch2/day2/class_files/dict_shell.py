Python 3.12.3 (tags/v3.12.3:f6650f9, Apr  9 2024, 14:05:25) [MSC v.1938 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
# Dictionary Data Type

dict1 = {"apple":"red","banana":"yellow"}
type(dict1)
<class 'dict'>
len(dict1)
2

# {key:value}
# Accessing elements from the dictionary
# No index numbers
# We use keys to access data

dict1["apple"]
'red'
dict1["banana"]
'yellow'
dict1["guava"]
Traceback (most recent call last):
  File "<pyshell#13>", line 1, in <module>
    dict1["guava"]
KeyError: 'guava'

# get(key)

dict1.get("apple")
'red'

dict1.get("apple","not found")
'red'

dict1.get("guava","not found")
'not found'

dict1.get("guava")

# Duplicate keys are not allowed
# Dupicate values are allowed

# Keys -> only immtable data types are allowed -> numbers,string,tuple
# values -> any data type is fine

# Dictionary is a mutable data type

dict1 = {"name":"sam","age":25}

dict1["age"] = 35
dict1
{'name': 'sam', 'age': 35}

dict1["address"] = "bangalore"
dict1
{'name': 'sam', 'age': 35, 'address': 'bangalore'}

dict1["phone"] = 998877
dict1
{'name': 'sam', 'age': 35, 'address': 'bangalore', 'phone': 998877}

# update() :- add 1 dict elements to another dict

dict1
{'name': 'sam', 'age': 35, 'address': 'bangalore', 'phone': 998877}

dict2 = {"id":"adhar card"}

dict1.update(dict2)
dict1
{'name': 'sam', 'age': 35, 'address': 'bangalore', 'phone': 998877, 'id': 'adhar card'}

# keys() and values()
dict1.keys()
dict_keys(['name', 'age', 'address', 'phone', 'id'])

dict1.values()
dict_values(['sam', 35, 'bangalore', 998877, 'adhar card'])

# pop(key)

dict1.pop("age")
35

dict1
{'name': 'sam', 'address': 'bangalore', 'phone': 998877, 'id': 'adhar card'}

# clear()

# del

del dict1["address"]
dict1
{'name': 'sam', 'phone': 998877, 'id': 'adhar card'}


# zip()

list1 = ["name","age","address"]
list2 = ["sam",25,"bangalore"]

dict(zip(list1,list2))
{'name': 'sam', 'age': 25, 'address': 'bangalore'}

list(zip(list1,list2))
[('name', 'sam'), ('age', 25), ('address', 'bangalore')]

tuple(zip(list1,list2))
(('name', 'sam'), ('age', 25), ('address', 'bangalore'))

dict1 = {"even":[2,4,6],"odd":(1,3,5)}

dict1["even"]
[2, 4, 6]

dict1["even"].append(8)
dict1
{'even': [2, 4, 6, 8], 'odd': (1, 3, 5)}
>>> 
>>> dict1["odd"]
(1, 3, 5)
>>> 
>>> emp = {101:{"name":"sam","salary":1000},102:{"name":"john","salary":2000}}
>>> 
>>> emp[101]
{'name': 'sam', 'salary': 1000}
>>> 
>>> emp[101]['salary']
1000
>>> 
>>> emp[101]['salary'] = 1500
>>> emp
{101: {'name': 'sam', 'salary': 1500}, 102: {'name': 'john', 'salary': 2000}}
