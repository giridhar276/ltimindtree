def subNum(x,y):
    #print("Subtraction:",x-y)
    result = x-y
    return result,x,y,"hello world"
