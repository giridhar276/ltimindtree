def addNum(x,y):
    #print("Addition:",x+y)
    result = x+y
    return result
