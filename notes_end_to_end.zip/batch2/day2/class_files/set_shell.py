Python 3.12.3 (tags/v3.12.3:f6650f9, Apr  9 2024, 14:05:25) [MSC v.1938 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
# Set data type
# an unorderd collection of unique elements

a = {10,20,30,40,50,60}
type(a)
<class 'set'>

a
{50, 20, 40, 10, 60, 30}

b = {10,20,30,40,10,20,50,60,50}
b
{50, 20, 40, 10, 60, 30}
# No index numbers
# Only immutable data types are allowed

a.add(90)
a
{50, 20, 90, 40, 10, 60, 30}

a.remove(60)
a
{50, 20, 90, 40, 10, 30}

a.discard(40)
a
{50, 20, 90, 10, 30}

a.add(90)
a
{50, 20, 90, 10, 30}

a = {1,2,3,4,5}
b = {4,5,6,7,8}

# union
# set of all the elements from both set

a|b
{1, 2, 3, 4, 5, 6, 7, 8}

a.union(b)
{1, 2, 3, 4, 5, 6, 7, 8}

# intersection
# set of common elements

a&b
{4, 5}

a.intersection(b)
{4, 5}

# difference
a-b
{1, 2, 3}
a.difference(b)
{1, 2, 3}

b-a
{8, 6, 7}
b.difference(a)
{8, 6, 7}

# symmetric difference
# except the common elements
>>> 
>>> a^b
{1, 2, 3, 6, 7, 8}
>>> 
>>> a.symmetric_difference(b)
{1, 2, 3, 6, 7, 8}
>>> 
>>> # superset and subset
>>> 
>>> a = {1,2,3,4,5,6,7}
>>> b = {2,5,7}
>>> 
>>> b.issubset(a)
True
>>> 
>>> a.issuperset(b)
True
>>> 
