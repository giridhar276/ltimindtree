# User defined functions

#1
'''
def func():
    print("Hello world")

func()  # function call
'''

#2 function with parameter
'''
def func(text):
    print(text)

func("Hello world")
func("hello python")
'''

#3
# Simple calc program
# return keyword
'''
def addNum(x,y):
    #print("Addition:",x+y)
    result = x+y
    return result

def subNum(x,y):
    #print("Subtraction:",x-y)
    result = x-y
    return result,x,y,"hello world"

while True:
    print("1. Add\n2. Sub")
    ch = int(input("Enter choice:"))

    if ch == 1:
        print(addNum(10,20))
    elif ch == 2:
        var = subNum(100,20)
        print(var[1])
'''

# set default values to the function parameter
'''
def func(x=100,y=200):
    print(x)
    print(y)

func(10,20)
func()
'''

# *args and **kwargs
'''
def func(*args,**kwargs):
    print(args)
    print(kwargs)

func(10,20,30,"hello",first="sachin",last="kumar")
'''


import add
import sub


while True:
    print("1. Add\n2. Sub")
    ch = int(input("Enter choice:"))

    if ch == 1:
        print(add.addNum(10,20))
    elif ch == 2:
        var = sub.subNum(100,20)
        print(var)







        





































        















