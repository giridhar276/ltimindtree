# Bank App Project
# By using dictionary data type

'''
1) Create a New Account
{101:{name:sam,age:25,address:bangalore,phone:90777,amount:10000},102:{}}

2) Existing Cust
-> check bal
-> deposite
-> withdraw
'''

bank = {}  # empty dictionary

def newAccount():
    print("-- Add A New Account Here --")

    acc = input("Enter your new account number:")  #key
    # value
    list1 = ["Name","Age","Address","Phone","Amount"]
    list2 = []
    
    n = input("Enter name:")
    list2.append(n)
    a = input("Enter age:")
    list2.append(a)
    ad = input("Enter address:")
    list2.append(ad)
    p = input("Enter phone:")
    list2.append(p)
    amt = int(input("Enter amount:"))
    list2.append(amt)

    # Store data into dictionary
    bank[acc] = dict(zip(list1,list2))
    print(bank)

def existingCust():
    print("-- For Existing Customer --")

    acc = input("Enter your account number to fetch your details:")
    if acc in bank:
        print("-- Data Found --")
        print("1. Check Balance\n2. Deposite\n3. Withdraw")
        ch = int(input("Enter choice:"))
        if ch == 1:
            print("-"*30)
            print("Available Balance:",bank[acc]["Amount"])
            print("-"*30)

        elif ch == 2:
            amt_d = int(input("Enter amount to deposite:"))
            bank[acc]["Amount"] = bank[acc]["Amount"] + amt_d
            print("-"*30)
            print("Deposite Successfull ! Available balance is:",bank[acc]["Amount"])
            print("-"*30)

        elif ch == 3:
            amt_w = int(input("Enter amount to withdraw:"))
            if amt_w<=bank[acc]["Amount"]:
                bank[acc]["Amount"] = bank[acc]["Amount"] - amt_w
                print("-"*30)
                print("Withdraw Successfull ! Available balance is:",bank[acc]["Amount"])
                print("-"*30)
            else:
                print("-- Wait for salary --")
        
    else:
        print("-- Data Not Found --")

while True:
    print("1. Create A New Account\n2. Existing Customer\n3. Exit")
    ch = int(input("Enter choice:"))

    if ch == 1:
        newAccount()   # function call
    elif ch == 2:
        existingCust()
    elif ch == 3:
        print("-- Thank You ! Please visit again --")
        break








    
