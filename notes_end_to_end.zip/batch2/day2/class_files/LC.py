# List comprehension

#1
'''
list1 = [10,20,30,40,50]
list2 = []
for i in list1:
    list2.append(i*5)
print(list2)

# LC

list1 = [10,20,30,40,50]
list2 = [i*5 for i in list1]
print(list2)
'''

#2
'''
list1 = []
for i in range(1,11):
    if i%2 == 0:
        list1.append(i)
print(list1)


# LC

even = [i for i in range(1,11) if i%2==0]
print(even)
'''

# DC

squares = {i:i**2 for i in range(1,11)}
print(squares)

















