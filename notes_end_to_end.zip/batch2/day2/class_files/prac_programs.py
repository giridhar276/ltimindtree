# Practice Programs

#1
# Multiplication Table Program
'''
Enter a number: 5
5x1 = 5
5x2 = 10
.
.
5x10 = 50
'''
'''
def table(num):
    # function body
    for i in range(1,11):
        print(num,'x',i,'=',num*i)

n = int(input("Enter a number:"))
table(n)
'''

#2
'''
Filter names starting with the vowel
'''
'''
names = ["anuj","prateek","shaily","seema","uttam","eshaan"]

v_names = []
for i in names:
    if i[0] in "aeiouAEIOU":
        v_names.append(i)
print(v_names)
'''

#3
# count int and strings in your list

'''
list1 = [100,200,"hello","python",150,287,"java"]

count_int = 0
count_str = 0

for i in list1:
    if type(i) == int:
        count_int = count_int+1
    elif type(i) == str:
        count_str = count_str+1

print("Total Integers:",count_int)
print("Total Strings:",count_str)
'''

#4
'''
Validate a string
Should start with an alphabet and it should end with a number

Enter a string: apple5
Valid string

Enter a string: 7sdfs9
Invalid string
'''
'''
def validateString(string):
    if string[0].isalpha() and string[-1].isdigit():
        print("valid string")
    else:
        print("Invalid")


validateString("5pple5")
'''

#5
'''
files = ['a.txt','b.pdf','c.jpg']

txt = []
pdf = []
jpg = []
'''

#6
# Factorial
'''
4! -> 4*3*2*1 = 24
'''
'''
num = int(input("Enter a number: "))
factorial = 1
if num <0: 
    print("Factirial does not exist for negative numbers")
elif num == 0: 
    print("Factorial of 0 is 1")
else: 
    for i in range(1, num+1): 
        factorial = factorial*i 
    print(f'The factorial of {num} is {factorial}')
'''
#7
'''
Write a Python Program to Check Prime Number.
Prime Numbers:
A prime number is a whole number that cannot be evenly divided by any other number
except for 1 and itself. For example, 2, 3, 5, 7, 11, and 13 are prime numbers because
they cannot be divided by any other positive integer except for 1 and their own value.
'''


n=int(input("enter the number to check is its prime: "))
c=0
if n>1:
    for i in range(1,n+1):
        if n%i==0:
            c+=1
    if c==2:
        print("the number entered is prime")
    else:
        print("the number is not prime")
else:
    print("entera number greater than 1")
        





























































































