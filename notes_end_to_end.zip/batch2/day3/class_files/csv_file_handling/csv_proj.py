# Corona DB Project
'''
1) Add Data -> country name, positive cases, recovered case and death cases
2) Show Data -> display data here
'''
import csv

def addData():
    print("-- Add New Data Here --")
    f = open("corona.csv","a",newline="")

    obj = csv.writer(f)
    cn = input("Enter country name:")
    pc = input("Enter positive cases:")
    rc = input("Enter recoverd cases:")
    dc = input("Enter death cases:")
    
    obj.writerow([cn,pc,rc,dc])
    f.close()
    print("-- Data Added Successfully --")

def showData():
    f = open("corona.csv")
    data = list(csv.reader(f))
    for i in data:
        print(i)
    print("-"*30)
    f.close()

def plotData():
    f = open("corona.csv")
    data = list(csv.reader(f))
    country_name = []
    positive_cases = []
    recovered_cases = []
    for i in data:
        country_name.append(i[0])
        positive_cases.append(int(i[1]))
        recovered_cases.append(int(i[2]))

    print(country_name)
    print(positive_cases)

    import matplotlib.pyplot as plt

    plt.plot(country_name,positive_cases)
    plt.plot(country_name,recovered_cases)

    plt.xlabel("Country Name")
    plt.ylabel("CN/PC")
    plt.title("Corona DB")
    plt.show()

while True:
    print("1. Add Data\n2. Show Data\n3. Plot Data\n4. Exit")
    ch = int(input("Enter choice:"))

    if ch == 1:
        addData()
    elif ch == 2:
        showData()
    elif ch == 3:
        plotData()
    elif ch == 4:
        break
    else:
        print("-- Invalid Choice --")
