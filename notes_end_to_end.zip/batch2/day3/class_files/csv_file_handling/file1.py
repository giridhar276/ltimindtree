# CSV file handling
# Comma Seperated Values

import csv

# read data from the csv file
'''
f = open("data.csv")
data = list(csv.reader(f))
print(data)

for i in data:
    print(i[0])
f.close()
'''

# Write data to the csv file

f = open("data.csv","w",newline="")

obj = csv.writer(f)
obj.writerow(["sam","sam@email.com"])
obj.writerow(["john","john@email.com"])
obj.writerow(["mike","mike@email.com"])

f.close()












