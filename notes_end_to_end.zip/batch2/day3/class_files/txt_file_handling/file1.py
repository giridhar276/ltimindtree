# txt file handling
'''
1) open a file
2) read/write
3) close the file

open(filename,mode)
mode :- r(read), w(write) and a(append)
'''

#1
'''
f = open("source.txt","r")
print(f.read())
f.close()
'''

#2
# readlines() :- will return a list of each line
'''
f = open("source.txt") # by deafult this will open the file in read mode
print(f.readlines())
f.close()
'''

# to write data -> w mode and a mode
# 1
'''
f = open("source.txt","w")
f.write("Hello how are you")
f.close()
'''

#2
'''
f = open("source.txt","a")
f.write("\nThis is python training")
f.close()
'''

#3
# both w and a mode will create a new file if the file does not exist
'''
f = open("abc.txt","w")
f.write("Hello how are you")
f.close()
'''

# writelines(list)
'''
f = open("new.txt","w")
list1 = ["python\n","java\n","C++"]
f.writelines(list1)
f.close()
'''

# By using with keyword
'''
with open("source.txt") as f:
    print(f.read())
'''
'''
with open("source.txt","w") as f:
    f.write("This is LTIM")
'''

# Examples

def readFile():
    f = open("source.txt")
    str1 = f.read()
    f.close()
    return str1

#1 Count Vowels
'''
var = readFile()
print(var)

count = 0
for i in var:
    if i in "aeiouAEIOU":
        count = count+1
print("Total Vowels:",count)
'''

#2 Count Consonants
#3 Count Punctuations
'''
import string
var = readFile()

count = 0
for i in var:
    if i in string.punctuation:
        count += 1

print("Total punctuation:",count)
'''
#4 Count Lines
'''
f = open("source.txt")
list1 = f.readlines()
print(list1)
print("Total Lines:",len(list1))
f.close()
'''

#5

var = readFile()
new_txt = var.upper()

f = open("data.txt","w")
f.write(new_txt)
f.close()































    


















































































