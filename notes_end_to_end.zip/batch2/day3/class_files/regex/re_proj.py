# Supermarket DB Mgnt project

'''
1) Extract data from the txt file -> regex
2) generate a report in csv format

profit = (sp-cp)*q

Prod   Q      CP     SP     Profit
k      10    90     100       100
b      20    12      15        60
                   Total      1200
'''

import re, csv

pat = """Product:\s(\w+)
Quantity:\s(\w+)
CP:\s(\w+)
SP:\s(\w+)"""

f = open("source.txt")
txt = f.read()
f.close()

match = re.findall(pat,txt)
##print(match)

f = open("report.csv","w",newline="")
obj = csv.writer(f)

obj.writerow(["Product","Quantity","CP","SP","Profit"])

total = 0
for i in match:
    profit = (int(i[-1])-int(i[-2])) * int(i[-3])
    total = total + profit
    list1 = list(i)
    list1.append(profit)
    obj.writerow(list1)

obj.writerow(["","","","Total",total])

f.close()




























