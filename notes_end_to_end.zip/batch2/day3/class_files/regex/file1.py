# Regular Expressions
# a regex is a sequence of characters that forms a search pattern.

import re

# search()

#1
##match = re.search("cat","hello how are you")
##print(match.group())

#2
'''
pat = "hello"
f = open("file1.txt")
txt = f.read()
f.close()

match = re.search(pat,txt)

if match:
    print("Match Found:",match.group())
else:
    print("Match not found")
'''

# findall() :- will return a list of all matching pattern

#eg1

##pat = "hello"
##f = open("file1.txt")
##txt = f.read()
##f.close()
##
##match = re.findall(pat,txt)
##print(match)

#eg2

##pat = r"\d\d"
##pat = "\d+"  # digits 1 or more
##
##f = open("file2.txt")
##txt = f.read()
##f.close()
##
##match = re.findall(pat,txt)
##print(match)

# eg3

##pat = "\d\d\d-\d\d\d-\d\d\d\d"
##pat = "\d{3}-\d{3}-\d{4}"
'''
pat = "\d{3}[-*]\d{3}[-*]\d{4}"

f = open("file3.txt")
txt = f.read()
f.close()

match = re.findall(pat,txt)
print(match)
'''

#eg4

##pat = "\d+\s\w+"
##
##f = open("file4.txt")
##txt = f.read()
##f.close()
##
##match = re.findall(pat,txt)
##print(match)


# eg5
# Email address

pat = "(\S+)@(\S+)"

f = open("file5.txt")
txt = f.read()
f.close()

match = re.findall(pat,txt)
print(match)
































