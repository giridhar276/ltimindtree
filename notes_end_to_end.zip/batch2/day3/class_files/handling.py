# Exceptional Handling in Python

#1
'''
try:
    n1 = int(input("Enter num1:")) # ValueError:
    n2 = int(input("Enter num2:")) # ValueError:
    result = n1/n2  # ZeroDivisionError:
    print(result)

except ZeroDivisionError:
    print("You cannot divide a number by zero")

except ValueError:
    print("-- Invalid Input --")
'''

#2
# Exceptional handling with function Re-call
'''
def func():
    try:
        n1 = int(input("Enter num1:")) # ValueError:
        n2 = int(input("Enter num2:")) # ValueError:
        result = n1/n2  # ZeroDivisionError:
        print(result)

    except ZeroDivisionError:
        print("You cannot divide a number by zero")
        func()

    except ValueError:
        print("-- Invalid Input --")
        func()

func()  # function call
'''


#3
# Generic except block that handles all the exception
'''
try:
    n1 = int(input("Enter num1:")) # ValueError:
    n2 = int(input("Enter num2:")) # ValueError:
    result = n1/n2  # ZeroDivisionError:
    print(result)

except:  # catches any type of exception
    print("-- Error --")
'''


#4
'''
try:
    n1 = int(input("Enter num1:")) # ValueError:
    n2 = int(input("Enter num2:")) # ValueError:
    result = n1/n2  # ZeroDivisionError:
    print(result)

except Exception as e:
    print(e)

finally:
    print("-- Bye --")
'''

# User defined exception
# raise keyword
# Guess the number game

class SmallError(Exception):
    pass
class LargeError(Exception):
    pass
import random
number = random.randint(1,100)
while True:
    num = int(input("Please guess the number:"))
    try:
        if num<number:
            raise SmallError
        elif num>number:
            raise LargeError
        else:
            break

    except SmallError:
        print("Your number is SMALL ! Please guess the BIG number")
    except LargeError:
        print("Your number is BIG ! Please guess the SMALL number")
        
print("Congratulations ! You won the game")
    




































    













    
















    
