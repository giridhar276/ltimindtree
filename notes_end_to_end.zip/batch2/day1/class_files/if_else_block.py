# Conditional Programming
# if - else block

#1
'''
marks = int(input("Enter your marks:"))

if marks<35:
    print("Fail")
    print("Study hard for the next year")
else:
    print("Pass")
    print("Lets Party")
'''

#2
# if - elif - elif - elif .... else
'''
marks = int(input("Enter your marks:"))

if marks<35:
    print("Grade D")
elif marks>=35 and marks<50:
    print("Grade C")
elif marks>=50 and marks<75:
    print("Grade B")
elif marks>=75 and marks<=100:
    print("Grade A")
else:
    print("Invalid Input")
'''

#3
# validate a phone number
# isdigit()
'''
phone = input("Enter your phone number:")

if phone.isdigit() and len(phone)==10:
    print("Valid Phone")
else:
    print("Invalid Phone")
'''

#4
# even or odd
'''
num = int(input("Enter a number:"))

if num%2 == 0:
    print("Even")
else:
    print("Odd")
'''

#5
# check for a vowel or consonant
# if char=="a" or char=="e" or char=="i" or char=="u"
'''
char = input("Enter a char:")

if char.isalpha() and len(char)==1:
    if char in "aeiou":
        print("Vowel")
    else:
        print("Consonant")

else:
    print("Invalid Input")
'''
#6
'''
Write a Python Program that accepts the 3 sides of a triangle as input.
An isosceles triangle has 2 equal sides.
A scalene triangle has no equal sides.
An equilateral triangle has all 3 equal sides
'''
'''
s1=int(input("Enter s1 value:"))
s2=int(input("Enter s2 value:"))
s3=int(input("Enter s3 value:"))


if s1==s2==s3:
    print("Equilateral Triangle")
elif s1==s2 or s2==s3 or s1==s3:
    print("Isoscele Triangle")
else:
    print("Scalene Triangle")
'''

#7

'''
Write a Python Program using 'if/elif/else' conditionals to compute the BMI of a person,
and return the risk associated with cardiovascular diseases.

Formula to calculate BMI
BMI = weight(kg)/(height(m)*height(m))


BMI	        Risk
27.5 and above	High Risk
23 - 27.4	Moderate Risk
18.5 - 22.9	Low Risk
Below 18.5	Risk of nutritional deficiency diseases
'''






























    







































    
