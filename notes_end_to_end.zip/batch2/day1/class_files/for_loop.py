# for loop

#1
'''
list1 = [10,20,30,40,50]

for item in list1:
    print(item*5)

print("Bye")
'''

#2
'''
list1 = [10,20,30,40,50]
list2 = []
for item in list1:
    list2.append(item*5)

print(list2)    
'''

#3
'''
list1 = [1,2,3,4,5,6,7,8,9,10]
even = []
odd = []

for i in list1:
    if i%2 == 0:
        even.append(i)
    else:
        odd.append(i)

print(even)
print(odd)
'''

# range(start,stop,step)

#1
'''
for i in range(10):
    print(i)
'''

#2
'''
for i in range(100,110):
    print(i)
'''

#3
'''
for i in range(100,110,2):
    print(i)
'''

#4
'''
for i in range(110,100,-1):
    print(i)
'''

#eg
'''
range(1000,1500)
print all the numbers which are divisible by 7
'''
'''
list1 = []
for i in range(1000,1500):
    if i%7 == 0:
        list1.append(i)

print(list1)
print("Total Elements:",len(list1))
'''

# eg
# for loop with the string data type

#1
'''
str1 = input("Enter a string:")
v = []
c = []

for i in str1:
    if i in "aeiouAEIOU":
        v.append(i)
    elif i == " ":
        continue
    else:
        c.append(i)

print(v,"Total Vowels:",len(v))
print(c,"Total Consonants:",len(c))
'''

#2
'''
Enter a string: gntjgnj4354@%$#%@$#36436fedegfvd   5465eedgs
alpha = []    -> isalpha()
num = []      -> isdigit()
garbage = []
'''

# eg
# perc/avg calc program
'''
sub = int(input("Enter number of subjects:"))

list1 = []
for item in range(1,sub+1):
    marks = int(input("Enter your marks in Sub%i:"%item))
    list1.append(marks)

print(list1)
perc = sum(list1)/sub
print("Percentage: %.2f"%perc)
'''

#eg



##list1.sort()
##print(list1[-2])


#eg
'''
Write a python program to create a list of tuples with the first element
as the number and second element as the square of the number.
Enter the lower range:5
Enter the upper range:10
[(5, 25), (6, 36), (7, 49), (8, 64), (9, 81), (10, 100)]
'''
'''
lr=int(input("enter lower range num:"))
ur=int(input("enter upper range num:"))
l1=[]
for i in range(lr,ur+1):
    a=(i,i**2)
    l1.append(a)
print(l1)
'''

#
'''
1) Write a python program to replace all occurrences of ‘a’ with ‘$’ in a string. 

--Output— 
Enter string: an apple in a day keeps doctor away 
Modified string: $n $pple in $ d$y keeps doctor $w$y
'''

#
'''
Check if a String is a Palindrome
A palindrome is a word, phrase, or sequence that reads the same backward as
forward (e.g., "madam" or "level"). This program checks if the entered string is a palindrome. It ignores spaces and is case-insensitive.

--Output--
Enter string: Racecar
'Racecar' is a palindrome.
'''
'''
s=input("enter string")
if s[::-1]== s:
    print("palindrome")
else:
    print("not a palindrome\n byee byeee...")
'''

#eg
'''
Write a python program to calculate the number of words and the
number of characters present in a string. 

--Output-- 
Enter string: this is python training 
Number of words in the string: 
4 
Number of characters in the string: 
20

'''
'''
string = input("string : ")
withoutSpace = string.replace(" ","")
wordCount = string.split(" ")
print("word count : ",len(wordCount),"charcters : ",len(withoutSpace))
'''

#eg
'''
count lower and upper case chars

Enter a string: appLE
total lower: 3
total upper: 2
'''














    













































































































































