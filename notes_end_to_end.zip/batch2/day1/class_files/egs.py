# Examples

#1

##fname = input("Enter first name:")
##mname = input("Enter mid name:")
##lname = input("Enter last name:")
##
##print("Good Morning!!",fname,mname,lname)
##
##print("Good Morning!! %s %s %s"%(fname,mname,lname))
##
##print(f"Good Morning!! {fname} {mname} {lname}")
##
##print("Good Morning!! {} {} {}".format(fname,mname,lname))


#2
# avg/perc marks
# highest marks and lowest

##s1 = int(input("Enter your marks in Sub1:"))
##s2 = int(input("Enter your marks in Sub2:"))
##s3 = int(input("Enter your marks in Sub3:"))
##s4 = int(input("Enter your marks in Sub4:"))
##s5 = int(input("Enter your marks in Sub5:"))
##
##avg = (s1+s2+s3+s4+s5)/5
##
##print("Percentage:",avg)
##
##print("Highest marks:",max(s1,s2,s3,s4,s5))
##
##lowest = min(s1,s2,s3,s4,s5)
##print("Lowest Marks: %i"%lowest)

#3
# Calculate the area of a triangle
# area = (1/2) * base * height

##base = float(input("Enter base:"))
##print() # all 4 differnt formats

#4

# Convert Celsius to Fahrenheit
##fahrenheit = (celsius * 9/5) + 32


var = 21/7
print("Value: %.3f"%var)




























