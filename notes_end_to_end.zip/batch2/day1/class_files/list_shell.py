Python 3.12.3 (tags/v3.12.3:f6650f9, Apr  9 2024, 14:05:25) [MSC v.1938 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
# List data type

a = [10,20,30,40,50]
type(a)
<class 'list'>

b = [10,20,"hello","python",6.8,True]
type(b)
<class 'list'>

c = [10,20,30,10,20,10]
c
[10, 20, 30, 10, 20, 10]

d = list()
type(d)
<class 'list'>

str1 = str()
type(str1)
<class 'str'>

# Accessing elements from the list
# index numbers

a
[10, 20, 30, 40, 50]

a[2]
30
a[-1]
50
a[1:3]
[20, 30]

a[1:]
[20, 30, 40, 50]
a[:3]
[10, 20, 30]
a[::1]
[10, 20, 30, 40, 50]
a[::-1]
[50, 40, 30, 20, 10]

# List is a mutable data type

a[2] = 300
a
[10, 20, 300, 40, 50]

a[4] = 500
a
[10, 20, 300, 40, 500]

a[1:3] = [11,22,33,44]
a
[10, 11, 22, 33, 44, 40, 500]

a[1] = ["sam","john"]
a
[10, ['sam', 'john'], 22, 33, 44, 40, 500]

a[3:4] = ["hello",100,200]
a
[10, ['sam', 'john'], 22, 'hello', 100, 200, 44, 40, 500]

a[1][-1][-1]
'n'

a[1][-1][-1] = "k"
Traceback (most recent call last):
  File "<pyshell#50>", line 1, in <module>
    a[1][-1][-1] = "k"
TypeError: 'str' object does not support item assignment

a[1][-1] = "mike"
a
[10, ['sam', 'mike'], 22, 'hello', 100, 200, 44, 40, 500]

# list built in functions
# append(element)

a
[10, ['sam', 'mike'], 22, 'hello', 100, 200, 44, 40, 500]

a = [10,20,30]
a.append(40)
a
[10, 20, 30, 40]
a.append("hello")
a
[10, 20, 30, 40, 'hello']

# insert(index_num,element)

a.insert(2,"python")
a
[10, 20, 'python', 30, 40, 'hello']

# extend() :- add 1 list elements to another list
a
[10, 20, 'python', 30, 40, 'hello']
b = [100,200]

a.extend(b)
a
[10, 20, 'python', 30, 40, 'hello', 100, 200]

# list3 = list1 + list2

# remove(element)

a.remove("hello")
a
[10, 20, 'python', 30, 40, 100, 200]

# pop(index_num)
a.pop(2)
'python'
a
[10, 20, 30, 40, 100, 200]

a.clear()
a
[]

del a
a
Traceback (most recent call last):
  File "<pyshell#93>", line 1, in <module>
    a
NameError: name 'a' is not defined

b
[100, 200]

del b[1]
b
[100]

a = [10,20,30,40,50]
len(a)
5
max(a)
50
min(a)
10
sum(a)
150

# count(element)

a

list1 = [10,20,30,40,10,20,10]
list1.count(10)
3
list1.count(20)
2

# sort() :- ascending order

a = [60,23,45,90,100,23]
a.sort()
a
[23, 23, 45, 60, 90, 100]

# reverse()
a.reverse()
a
[100, 90, 60, 45, 23, 23]

# index(element)

a.index(60)
2

a.index(90)
1

d = list()
>>> type(d)
<class 'list'>
>>> 
>>> # tuple data type
>>> # immutable list
>>> 
>>> a = (10,20,30,40)
>>> type(a)
<class 'tuple'>
>>> 
>>> a[2]
30
>>> a[2:4]
(30, 40)
>>> a[::-1]
(40, 30, 20, 10)
>>> 
>>> a[2] = 100
Traceback (most recent call last):
  File "<pyshell#142>", line 1, in <module>
    a[2] = 100
TypeError: 'tuple' object does not support item assignment
