a = int(input("Enter the value of a:"))
b = int(input("Enter the value of b:"))
result = a+b


# part1
##print("The sum of a and b is",result)
##print("The sum of",a,"and",b,"is",result)

# part2
print("The sum of %i and %i is %i"%(a,b,result))

# %i -> int
# %f -> float
# %s -> str

# part3
print(f"The sum of {a} and {b} is {result}")

# part4

print("The sum of {} and {} is {}".format(a,b,result))
