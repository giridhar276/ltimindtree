Python 3.12.3 (tags/v3.12.3:f6650f9, Apr  9 2024, 14:05:25) [MSC v.1938 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
# String indexing

a = "python"

a[a]
Traceback (most recent call last):
  File "<pyshell#4>", line 1, in <module>
    a[a]
TypeError: string indices must be integers, not 'str'

a[2]
't'

a[-4]
't'

a[-1]
'n'

# Accessing multiple elements
# : -> slicing operator

# [start:stop]

a[1:4]
'yth'

a[-5:-2]
'yth'

a[4:1]
''

# [start:stop:step]
# step => 1

a[1:4:1]
'yth'

a[4:1:1]
''

a[4:1:-1]
'oht'

a[:3]
'pyt'

a[2:]
'thon'

a[:]
'python'

a[::-1]
'nohtyp'

a[::2]
'pto'

a[::-2]
'nhy'


a[1:-2:2]
'yh'

a[1::3]
'yo'

a[:1:-2]
'nh'

a[-4::-1]
'typ'


a[1:-2:-2]
''

a[3:3]
''

# string built in functions
# capitalize()

a = "pyTHoN"

a.capitalize()
'Python'

a
'pyTHoN'
# string is an immutable data type

b = a.capitalize()
a
'pyTHoN'
b
'Python'

# lower() and upper()

a.lower()
'python'

a.upper()
'PYTHON'

# swapcase()
a
'pyTHoN'
a.swapcase()
'PYthOn'

# title()

a = "ThIS iS pyTHON TRAIning"

a.title()
'This Is Python Training'

# count()

a = "i play cricket and i play chess"

a.count("play")
2

a.count("i")
3

a.count("i ")
2

a.count(" i ")
1

a.count("I")
0

# alt+p -> to get the previous commands

# islower() and isupper()
# Bool -> True or False

a = "abc"
a.islower()
True

a = "aBc"
a.islower()
False

a = "ABC"
a.isupper()
True

# isdigit() and isalpha()

phone = "845748675"
phone.isdigit()
True

phone = "46564fsdrd"
phone.isdigit()
False

name = "sam"
name.isalpha()
True

name = "sam123"
name.isalpha()
False

# isalnum() -> alpha - numeric

# find() and index()

a = "this is python training"
a.find("python")
8

a.index("python")
8

a.find("car")
-1

a.index("car")
Traceback (most recent call last):
  File "<pyshell#141>", line 1, in <module>
    a.index("car")
ValueError: substring not found

a.find("is")
2

a.find("is",3)
5

a.find("is",3,10)
5
a.find(" is")
4

# replace()

str1 = "hello john and hello michal"

str1.replace("hello","hi")
'hi john and hi michal'

str1
'hello john and hello michal'

# split()
# will return a list of substring

str1 = "hello how are you"
>>> str1.split()
['hello', 'how', 'are', 'you']
>>> 
>>> # len()
>>> 
>>> a = "hello"
>>> len(a)
5
>>> 
>>> b = [10,20,30]
>>> len(b)
3
>>> 
>>> ip = "198.168.2.1"
>>> ip.split()
['198.168.2.1']
>>> 
>>> ip.split(".")
['198', '168', '2', '1']
