Python 3.12.3 (tags/v3.12.3:f6650f9, Apr  9 2024, 14:05:25) [MSC v.1938 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
# variables
a = 10
type(a)
<class 'int'>

b = 2.5
type(b)
<class 'float'>

c = "hello"
type(c)
<class 'str'>

# Rules of writing variable names
# Start -> a-z or A-Z or _
# Not start -> 0-9

abc = 10
Abc = 10
_ab = 10

2ab = 10
SyntaxError: invalid decimal literal

a2b = 10
ab3 = 10
ab cd = 10
SyntaxError: invalid syntax

ab_cd = 10

# Keywords are not allowed
# python is case sensitive

true = 10
True = 10
SyntaxError: cannot assign to True

import keyword
keyword.kwlist
['False', 'None', 'True', 'and', 'as', 'assert', 'async', 'await', 'break', 'class', 'continue', 'def', 'del', 'elif', 'else', 'except', 'finally', 'for', 'from', 'global', 'if', 'import', 'in', 'is', 'lambda', 'nonlocal', 'not', 'or', 'pass', 'raise', 'return', 'try', 'while', 'with', 'yield']

# Arithmetic operators

5+2
7
5-2
3
5*2
10
5/2
2.5

5%2
1

5//2
2

# // -> floor division

2**5
32
>>> 
>>> # ** -> exponent
>>> 
>>> # String data type
>>> 
>>> a = "hello"
>>> type(a)
<class 'str'>
>>> 
>>> b = 'python'
>>> type(b)
<class 'str'>
>>> 
>>> # AO -> + and *
>>> 
>>> a+b
'hellopython'
>>> 
>>> a*2
'hellohello'
>>> 
>>> b*5
'pythonpythonpythonpythonpython'
